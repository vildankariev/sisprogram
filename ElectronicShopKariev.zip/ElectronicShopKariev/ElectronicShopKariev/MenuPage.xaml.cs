﻿using ElectronicShopKariev.DatabaseContext;
using ElectronicShopKariev.Entities;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Windows;
using System.Windows.Controls;
namespace ElectronicShopKariev
{
    
    public partial class MenuPage : Window
    {
        public MenuPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void OpenAddProductWindow(object sender, RoutedEventArgs e) {
            AddProductWindow addProductWindow = new AddProductWindow();
            addProductWindow.ShowDialog();
            LoadData();
        }

        private void GoToEditProductWindow(object sender, SelectionChangedEventArgs e)
        {
            ProductEntity selectedProduct = (ProductEntity)ProductLV.SelectedItem;
            if (selectedProduct == null) return;

            UpdateProductWindow  editPage = new UpdateProductWindow (selectedProduct.Id);
            editPage.ShowDialog();
            LoadData();
        }


        private void LoadData()
        {
            ApplicationDbContext dbContext = new ApplicationDbContext();
            ProductLV.ItemsSource = dbContext.Products.ToList();
        }
    }
}
