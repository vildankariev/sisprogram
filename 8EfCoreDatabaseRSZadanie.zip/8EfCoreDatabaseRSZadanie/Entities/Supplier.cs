﻿using System;
using System.Collections.Generic;

namespace EfCoreDatabaseRSZadanie.Entities;

public partial class Supplier
{
    public int SupplierId { get; set; }

    public string SupplierName { get; set; } = null!;

    public string ContactName { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string Address { get; set; } = null!;

    public virtual ICollection<Productsupplier> Productsuppliers { get; set; } = new List<Productsupplier>();
}
